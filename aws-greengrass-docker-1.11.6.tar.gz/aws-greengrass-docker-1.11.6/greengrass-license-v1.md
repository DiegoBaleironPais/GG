# License
License is available at https://s3-us-west-2.amazonaws.com/greengrass-release-license/greengrass-license-v1.pdf
